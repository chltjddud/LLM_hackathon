import React from "react";

interface Clause {
  id: string;
  clause_text: string;
  category: string;
  risk_level: string;
  resolved_by_tenant: boolean;
  resolved_by_landlord: boolean;
}

interface RevisedContractDocumentProps {
  clauses: Clause[];
  sessionDate?: string;
}

export const RevisedContractDocument: React.FC<RevisedContractDocumentProps> = ({ clauses, sessionDate }) => {
  // Only show clauses that were flagged or discussed, maybe just resolved ones
  // For this hackathon, we show all clauses analyzed, especially the resolved ones.
  const resolvedClauses = clauses.filter(
    (c) => c.resolved_by_tenant && c.resolved_by_landlord
  );

  return (
    <div id="pdf-contract-document" style={{ width: "210mm", minHeight: "297mm", padding: "20mm", backgroundColor: "white", color: "black", fontFamily: "'Noto Sans KR', sans-serif" }} className="hidden absolute left-[-9999px]">
      <h1 style={{ textAlign: "center", fontSize: "24pt", fontWeight: "bold", marginBottom: "20px" }}>
        특약사항 (합의안)
      </h1>
      <p style={{ textAlign: "right", fontSize: "12pt", marginBottom: "30px", color: "#555" }}>
        {sessionDate ? new Date(sessionDate).toLocaleDateString('ko-KR') : new Date().toLocaleDateString('ko-KR')} 기준
      </p>

      <div style={{ fontSize: "12pt", lineHeight: "1.8" }}>
        <p style={{ marginBottom: "20px" }}>
          본 문서는 임대인과 임차인 간의 계약 과정에서 <strong>계약방패</strong> 서비스를 통해 상호 합의된 특약사항을 정리한 내용입니다. 본 특약사항은 원본 계약서에 우선하여 적용될 수 있습니다.
        </p>

        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
          <thead>
            <tr>
              <th style={{ border: "1px solid #ccc", padding: "10px", backgroundColor: "#f9f9f9", width: "20%" }}>항목</th>
              <th style={{ border: "1px solid #ccc", padding: "10px", backgroundColor: "#f9f9f9", width: "80%" }}>합의된 조항 내용</th>
            </tr>
          </thead>
          <tbody>
            {resolvedClauses.length > 0 ? (
              resolvedClauses.map((clause, index) => (
                <tr key={clause.id}>
                  <td style={{ border: "1px solid #ccc", padding: "12px", textAlign: "center", fontWeight: "bold" }}>
                    {clause.category || `조항 ${index + 1}`}
                  </td>
                  <td style={{ border: "1px solid #ccc", padding: "12px" }}>
                    {clause.clause_text}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={2} style={{ border: "1px solid #ccc", padding: "20px", textAlign: "center" }}>
                  현재 상호 합의(해결) 처리된 특약 조항이 없습니다.
                </td>
              </tr>
            )}
          </tbody>
        </table>

        <div style={{ marginTop: "50px", textAlign: "center" }}>
          <p style={{ marginBottom: "10px" }}>위 특약사항에 대하여 양 당사자가 모두 확인하고 동의함.</p>
          <div style={{ display: "flex", justifyContent: "space-around", marginTop: "40px" }}>
            <div>
              <strong>임대인 (대리인)</strong><br /><br />(서명 또는 인)
            </div>
            <div>
              <strong>임차인</strong><br /><br />(서명 또는 인)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
